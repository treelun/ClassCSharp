using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics.CodeAnalysis;

namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Table03_01.Tests
{
    [TestClass]
    public class UppercaseTests
    {
        [NotNull]
        public TestContext? TestContext { get; set; }


    }
}