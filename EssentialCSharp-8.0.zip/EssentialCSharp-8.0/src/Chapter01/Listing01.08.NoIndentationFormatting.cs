namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_08
{
public class HelloWorld
{
public static void Main()
{
System.Console.WriteLine("Hello Inigo Montoya");
}
}
}
