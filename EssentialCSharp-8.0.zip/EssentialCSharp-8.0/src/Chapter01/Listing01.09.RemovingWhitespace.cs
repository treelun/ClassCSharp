namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_09
{
public class Program{public static void Main()
{System.Console.WriteLine("Hello Inigo Montoya");}}
}
