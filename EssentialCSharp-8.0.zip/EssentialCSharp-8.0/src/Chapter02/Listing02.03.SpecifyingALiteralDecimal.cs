namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_03
{
    public class Program
    {
        public static void Main()
        {
            System.Console.WriteLine(1.618033988749895M);
        }
    }
}
