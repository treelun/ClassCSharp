namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_11
{
    public class SingleQuote
    {
        public static void Main()
        {
            System.Console.WriteLine('\'');
        }
    }
}
