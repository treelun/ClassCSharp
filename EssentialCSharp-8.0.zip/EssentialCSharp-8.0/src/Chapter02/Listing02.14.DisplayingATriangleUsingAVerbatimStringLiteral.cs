namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_14
{
    public class Triangle
    {
        public static void Main()
        {
            System.Console.Write(@"begin
                   /\
                  /  \
                 /    \
                /      \
               /________\
end");
        }
    }
}
