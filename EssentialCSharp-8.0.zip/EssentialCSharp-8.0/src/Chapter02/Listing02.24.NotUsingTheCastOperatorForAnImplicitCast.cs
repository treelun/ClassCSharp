namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_24
{
    public class Program
    {
        public static void Main()
        {
            int intNumber = 31416;
            long longNumber = intNumber;
        }
    }
}
