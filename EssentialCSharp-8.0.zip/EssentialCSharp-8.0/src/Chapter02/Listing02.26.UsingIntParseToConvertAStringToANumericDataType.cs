namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_26
{
    public class Program
    {
        public static void Main()
        {
            string text = "9.11E-31";
            float kgElectronMass = float.Parse(text);
        }
    }
}
