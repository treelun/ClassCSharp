﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter06.Listing06_01
{
    public class Program
    {
        public static void Main()
        {
            System.Console.WriteLine("No output in this example");
        }
    }

    class Employee
    {
    }

}
