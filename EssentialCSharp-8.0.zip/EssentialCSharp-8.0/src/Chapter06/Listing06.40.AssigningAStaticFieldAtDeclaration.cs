namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter06.Listing06_40
{
    class Employee
    {
        // ...
        public static int NextId = 42;
        // ...
    }
}
