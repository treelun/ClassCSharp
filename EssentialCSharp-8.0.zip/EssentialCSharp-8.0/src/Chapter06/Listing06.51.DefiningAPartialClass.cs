namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter06.Listing06_51
{
    // File: Program1.cs
    partial class Program
    {
    }

    // File: Program2.cs
    partial class Program
    {
    }
}
