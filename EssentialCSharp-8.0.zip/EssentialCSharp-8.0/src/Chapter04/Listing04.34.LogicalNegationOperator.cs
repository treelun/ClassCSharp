namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_34
{
    public class Program
    {
        public static void Main()
        {
            bool valid = false;
            bool result = !valid;
            // Displays "result = True"
            System.Console.WriteLine($"result = { result }");
        }
    }
}
