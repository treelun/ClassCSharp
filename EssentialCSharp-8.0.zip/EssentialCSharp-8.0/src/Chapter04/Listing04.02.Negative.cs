namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_02
{
    public class Program
    {
        public static void Main()
        {
            //National Debt to the Penny
            decimal debt = -26457079712930.80M;

            System.Console.WriteLine(debt);
        }
    }
}
