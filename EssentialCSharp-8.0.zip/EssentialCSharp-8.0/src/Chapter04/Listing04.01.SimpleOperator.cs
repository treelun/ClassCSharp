namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_01
{
    public class Program
    {
        public static void Main()
        {
            int difference = 4 - 2;
            System.Console.WriteLine(difference);
        }
    }
}
