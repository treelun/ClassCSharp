namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_55
{
    public class Program
    {
        public static void Main()
        {
            // ...

#if CSHARP2PLUS
            System.Console.Clear();
#endif

            // ...
        }
    }
}
