namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_60
{
    public class Program
    {
#pragma warning disable CS1030
        public static void Main()
        {
#warning "Sample warning suppressed by #pragma warning disable."
        }
#pragma warning restore CS1030
    }
}
