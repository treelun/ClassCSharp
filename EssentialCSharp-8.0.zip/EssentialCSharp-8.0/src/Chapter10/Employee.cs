﻿namespace Chapter10
{
    class Employee
    {
    }
}
