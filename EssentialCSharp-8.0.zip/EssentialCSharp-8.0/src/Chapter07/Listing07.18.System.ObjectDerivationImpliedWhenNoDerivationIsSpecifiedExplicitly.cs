namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter07.Listing07_18
{
    public class PdaItem : object
    {
        // ...
    }
}
