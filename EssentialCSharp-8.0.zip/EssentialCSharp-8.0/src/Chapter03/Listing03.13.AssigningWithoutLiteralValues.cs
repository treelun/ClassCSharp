namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_13
{
    public class Program
    {
        public static void Main()
        {
            string[] languages = new string[9];
        }
    }
}
