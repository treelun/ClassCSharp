namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_16
{
    public class Program
    {
        public static void Main()
        {
            int[,] cells = {
                {1, 0, 2},
                {1, 2, 0},
                {1, 2, 1}
            };
        }
    }
}
