namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_10
{
    public class Program
    {
        public static void Main()
        {
            string[] languages;
            languages = new string[] { "C#", "COBOL", "Java",
                "C++", "TypeScript", "Visual Basic",
                "Python", "Lisp", "JavaScript" };
        }
    }
}
