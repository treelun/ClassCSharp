namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_12
{
    public class Program
    {
        public static void Main()
        {
            string[] languages = new string[9] { 
                "C#", "COBOL", "Java",
                "C++", "TypeScript", "Visual Basic",
                "Python", "Lisp", "JavaScript" };
        }
    }
}
