namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter09.Listing09_09
{
    enum ConnectionState
    {
        Disconnected,
        Connecting,
        Connected,
        Disconnecting
    }
}
